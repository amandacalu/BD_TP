# Import sqlite3 module 
import sqlite3 
import sys

# Connect to database
conn = sqlite3.connect('movie_stream.db')


# Create a cursor for SQL commands
cur = conn.cursor()
cur.row_factory = sqlite3.Row

# Execute query
n = cur.execute('SELECT COUNT(*) n FROM STREAM').fetchone()['n']
print('Before DELETE:', n, 'rows')
id = sys.argv[1] 
res = cur.execute('DELETE FROM STREAM WHERE StreamId = ' + id);
print(res.rowcount, 'rows deleted')
n = cur.execute('SELECT COUNT(*) n FROM STREAM').fetchone()['n']
print('After DELETE:', n, 'rows')

