# Import sqlite3 module 
import sqlite3 
import sys

# Connect to database
conn = sqlite3.connect('movie_stream.db')

# Create a cursor for SQL commands
cur = conn.cursor()
cur.row_factory = sqlite3.Row

# Execute query
year = sys.argv[1] 
res = cur.execute(
    '''
    SELECT Title, Year, Duration
    FROM MOVIE 
    WHERE YEAR =''' + year + ' ORDER BY Title')
for row in res.fetchall():
    print(row['Title'], row['Year'], row['Duration'])


