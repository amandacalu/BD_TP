# Import sqlite3 module 
import sqlite3 
import sys

# Connect to database
conn = sqlite3.connect('movie_stream.db')

# Create a cursor for SQL commands
cur = conn.cursor()
cur.row_factory = sqlite3.Row

# Execute query
year = sys.argv[1]
duration = sys.argv[2]
res = cur.execute(
    '''
    SELECT Title, Year, Duration
    FROM MOVIE 
    WHERE YEAR = :year AND DURATION <= :duration
    ORDER BY Duration
    ''', {'year': year, 'duration': duration})
    
for row in res.fetchall():
    print(row['Title'], row['Year'], row['Duration'])


