# Import sqlite3 module 
import sqlite3 
import sys

# Connect to database
conn = sqlite3.connect('movie_stream.db')

# Create a cursor for SQL commands
cur = conn.cursor()
cur.row_factory = sqlite3.Row

name = sys.argv[1] 
res = cur.execute('SELECT ActorId FROM ACTOR WHERE Name = ?', [name]).fetchone()
if res == None:
    print(name, ': actor not found')
    sys.exit(1)

id = res['ActorId']
res = cur.execute('DELETE FROM MOVIE_ACTOR WHERE ActorId=?', [id])
print(res.rowcount,'rows in MOVIE_ACTOR deleted')
res = cur.execute('DELETE FROM ACTOR WHERE ActorId = ?', [id]);
print(res.rowcount,'rows in ACTOR deleted')

if input('Commit  changes (Y/N)? ') == 'Y':
    conn.commit()
    print('Changes commited!')
else:
    conn.rollback()
    print('Changes rolled back!')


