# Import sqlite3 module 
import sqlite3 

# Connect to database
conn = sqlite3.connect('movie_stream.db')

# Create a cursor for SQL commands
cur = conn.cursor()
cur.row_factory = sqlite3.Row

# Execute query
res = cur.execute(
    '''
    SELECT Title, Year 
    FROM MOVIE 
    WHERE Title LIKE '%star wars%'
    ORDER BY Year DESC
    ''')

# Fetch all results and use them for something
data = res.fetchall()
for row in data:
    print('Title:', row['title'], ':: Year:', row['year'])
    # Alternatively we can use indexes:
    #  print('title:', row[0], 'year:', row[1])

   


