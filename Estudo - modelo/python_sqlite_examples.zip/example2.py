# Import sqlite3 module 
import sqlite3 

# Connect to database
conn = sqlite3.connect('movie_stream.db')

# Create a cursor for SQL commands
cur = conn.cursor()
cur.row_factory = sqlite3.Row

# Execute query
res = cur.execute(
    '''
    SELECT COUNT(*) n,  MIN(Year) min, MAX(Year) max
    FROM MOVIE 
    WHERE Title LIKE '%star wars%'
    ''')
# Fetch single row
data = res.fetchone()
print(data['n'], data['min'], data['max'])

